package com.example.myapplication.config
    const val NAME = "name"
    const val PASSWORD = "password"