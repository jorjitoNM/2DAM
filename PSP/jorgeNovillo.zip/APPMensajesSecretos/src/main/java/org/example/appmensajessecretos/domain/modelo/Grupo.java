package org.example.appmensajessecretos.domain.modelo;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import lombok.Data;

import java.util.ArrayList;

@Data
public class Grupo {
    private final String name;
    private final String password;
    private final ArrayList<Usuario> members;
    private final ArrayList<Mensaje> mensajes;

    public boolean joinGroup (Usuario user) {
        return members.add(user);
    }

    public Grupo(String name, String password) {
        this.name = name;
        this.password = password;
        members = new ArrayList<>();
        mensajes = new ArrayList<>();
    }

    public ArrayList<String> getMessages () {
        ArrayList<String> messages = new ArrayList<>();
        mensajes.forEach(m -> messages.add(m.toString()));
        return messages;
    }

    @Override
    public String toString() {
        return name;
    }
}
