package org.example.appmensajessecretos.domain.servicio;

import org.example.appmensajessecretos.dao.Dao;
import org.example.appmensajessecretos.domain.modelo.Grupo;
import org.example.appmensajessecretos.domain.modelo.Usuario;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Servicio {
    public ArrayList<String> getMessages (Dao dao, Grupo group)  {
        return dao.getGrupos().stream().filter(g -> g.equals(group)).findFirst().orElse(null).getMessages();
    }
    public List<Grupo> getGroups (Dao dao, Usuario user) {
        return dao.getGrupos().stream().filter(g -> g.getMembers().contains(user)).toList();
    }
    public boolean deleteMember (Dao dao, Usuario user, Grupo group) {
        return dao.getGrupos().stream().filter(g -> g.equals(group)).collect(Collectors.toSet()).remove(user);
    }
    public boolean logIn (Usuario user) {
        return true;
    }
    public boolean joinGroup (Dao dao, Usuario user, Grupo group) {
        return dao.joinGroup(user, group);
    }
    public boolean findUser (Dao dao, Usuario user) {
        return dao.findUser(user);
    }
    public Grupo createGroup (Dao dao, Grupo group) {
        return dao.createGroup(group);
    }

    public boolean findGroup(Dao dao, Grupo grupo) {
        return dao.findGroup(grupo);
    }

    public void addUser(Dao dao, Usuario usuario) {
        dao.addUser(usuario);
    }
}
