package org.example.appmensajessecretos.ui;

import lombok.Data;
import lombok.extern.log4j.Log4j2;
import org.example.appmensajessecretos.config.Constantes;
import org.example.appmensajessecretos.dao.Dao;
import org.example.appmensajessecretos.domain.modelo.Grupo;
import org.example.appmensajessecretos.domain.modelo.Mensaje;
import org.example.appmensajessecretos.domain.modelo.Usuario;
import org.example.appmensajessecretos.domain.servicio.Servicio;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Log4j2
@Data
public class HelloController {

    private Servicio service;
    private Dao dao;


    @FXML
    private Label enterUser;
    @FXML
    private TextField userName;
    @FXML
    private Label enterPassword;
    @FXML
    private TextField userPassword;
    @FXML
    private Button submitCredentials;
    @FXML
    private Label logInError;

    @FXML
    private Label enterGroupName;
    @FXML
    private TextField groupName;
    @FXML
    private Label enterGroupPassword;
    @FXML
    private TextField groupPassword;
    @FXML
    private Button joinGroup;
    @FXML
    private Label joinGroupError;

    @FXML
    private Label enterGroupNameDelete;
    @FXML
    private TextField groupNameDelete;
    @FXML
    private Label enterUserNameDelete;
    @FXML
    private TextField userNameDelete;
    @FXML
    private Label deleteError;
    @FXML
    private Button deleteUser;

    @FXML
    private Label misChats;
    @FXML
    private ChoiceBox chat;
    @FXML
    private ListView<String> myChats;

    @FXML
    private Label mensajeLabel;
    @FXML
    private TextArea mensaje;
    @FXML
    private Button envioGrupo;
    @FXML
    private Button envioPrivado;

    @FXML
    private Label chatActivoLabel;
    @FXML
    private AnchorPane chatActivo;

    private Usuario usuario;


    public HelloController() {
    }

    public void iniciarSesion () {
        service = new Servicio();
        dao = new Dao();
        if (userName.getText().isEmpty() || userPassword.getText().isEmpty())
            logInError.setText(Constantes.RELLENE_CAMPOS);
        else if (!service.findUser(dao,new Usuario(userName.getText(),userPassword.getText()))) {
            Alert create = new Alert(Alert.AlertType.CONFIRMATION);
            create.setTitle(Constantes.CREACION_USUARIO);
            create.setHeaderText("El usuario introducido no existe, ¿desea crearlo?");
            create.showAndWait();
            if (create.getResult() == ButtonType.OK) {
                usuario = new Usuario(userName.getText(), userPassword.getText());
                service.addUser(dao,usuario);
                actualizarGrupos();
                log.info(Constantes.LOG_NUEVO_USUARIO);
            } else {
                usuario = new Usuario(userName.getText(), userPassword.getText());
            }
            log.info(Constantes.LOG_LOGGED_IN);
        }
    }
    private boolean checkLogged () {
        return usuario != null;
    }

    public void comfirmDelete(ActionEvent actionEvent) {
        if (checkLogged()) {
            Alert comfirmation = new Alert(Alert.AlertType.CONFIRMATION);
            comfirmation.setTitle(Constantes.COMFIRMACION);
            comfirmation.setHeaderText(Constantes.MENSAJE_ELIMINAR_USUARIO);
            comfirmation.showAndWait();
            if (comfirmation.getResult() != ButtonType.OK)
                comfirmation.close();
        } else
            log.info(Constantes.LOG_NOT_LOGGED);
    }
    public void selectUser (ActionEvent actionEvent) {
        TextInputDialog selectUser = new TextInputDialog();
        selectUser.setTitle("Enviar mensaje a:");
        selectUser.setContentText("Introduzca el nombre del destinatario");
        Optional<String> respuesta = selectUser.showAndWait();
    }

    public void selecChat(ActionEvent actionEvent) {
        chat.getValue();
    }
    public void joinGroup(ActionEvent actionEvent) {
        if (checkLogged()) {
            if (enterGroupName.getText().isEmpty() || enterGroupPassword.getText().isEmpty())
                joinGroupError.setText(Constantes.RELLENE_CAMPOS);
            else {
                Grupo grupo = new Grupo(groupName.getText(), groupPassword.getText());
                if (!service.findGroup(dao, grupo)) {
                    joinGroupError.setText(Constantes.GRUPO_NO_EXISTE);
                    log.error(Constantes.GRUPO_NO_EXISTE);
                } else if (!service.joinGroup(dao, usuario, grupo)) {
                    joinGroupError.setText(Constantes.ERROR_JOINING_GROUP);
                    log.error(Constantes.ERROR_JOINING_GROUP);
                }
                else {
                    joinGroupError.setText(Constantes.JOINED_GROUP);
                    log.info(Constantes.JOINED_GROUP);
                    actualizarGrupos();
                }
            }
        } else
            log.info(Constantes.LOG_NOT_LOGGED);
    }

    private void actualizarGrupos() {
        ObservableList<Grupo> chats = FXCollections.observableList(service.getGroups(dao, usuario));
        List<String> chatsString = new ArrayList<>();
        chats.forEach(c -> chatsString.add(c.toString()));
        ObservableList<String> chatsFormatted = FXCollections.observableArrayList(chatsString);
        myChats.setItems(chatsFormatted);
    }

    public void enviarMensaje (ActionEvent actionEvent) {
        /*if (!messageChecks())
            log.error(Constantes.LOG_MISSING_FIELDS);
        else{
            Mensaje mensaje = new Mensaje(this.mensaje.getText(), LocalDateTime.now(), usuario, new Grupo(myChats.getEditingIndex()));
        }*/
    }
    private boolean messageChecks () {
        return (myChats.getEditingIndex() != -1) && (!mensaje.getText().isEmpty());
    }
}