package org.example.appmensajessecretos.domain.modelo;

import lombok.Data;

@Data
public class Usuario {
    private final String name;
    private final String password;
}
