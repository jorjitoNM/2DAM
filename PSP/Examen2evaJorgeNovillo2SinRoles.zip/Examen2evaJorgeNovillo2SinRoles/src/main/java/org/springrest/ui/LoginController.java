package org.springrest.ui;

import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import org.springrest.common.Constantes;
import org.springrest.domain.model.User;
import org.springrest.domain.services.UserService;
import org.springrest.security.jwt.JWTService;
import org.springrest.security.jwt.Token;
import org.springrest.ui.model.AuthUser;

@RestController
@RequiredArgsConstructor
public class LoginController {

    private final JWTService tokenService;
    private final UserService userService;

    @PostMapping(Constantes.LOGIN_URL)
    public ResponseEntity<Token> login(@RequestBody AuthUser user) {
        if (userService.login(new User(user.getEmail(), user.getPassword())))
            return ResponseEntity.ok(tokenService.getToken(user.getEmail()));
        else
            return ResponseEntity.status(HttpServletResponse.SC_UNAUTHORIZED).build();
    }

    @PostMapping(Constantes.REFRESH_URL)
    public ResponseEntity<Token> refresh (@RequestHeader(HttpHeaders.AUTHORIZATION) String refreshToken) {
        return ResponseEntity.ok(tokenService.getToken(tokenService.getEmail(refreshToken.split("Bearer ")[1].trim())));
    }
}
