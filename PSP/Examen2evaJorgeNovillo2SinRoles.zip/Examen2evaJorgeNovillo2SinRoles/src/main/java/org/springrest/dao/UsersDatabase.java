package org.springrest.dao;

import lombok.Getter;
import org.springframework.stereotype.Repository;
import org.springrest.common.Constantes;
import org.springrest.domain.errors.NotFoundException;
import org.springrest.domain.model.User;

import java.util.ArrayList;
import java.util.List;

@Getter
@Repository
public class UsersDatabase {
    
    private List<User> users;

    public UsersDatabase() {
        this.users = new ArrayList<>();
        users.add(new User("hola","1234"));
    }

    public User findUserByEmail(String email) {
        return users.stream().filter(user -> user.getEmail().equals(email)).findFirst().orElseThrow(() -> new NotFoundException(Constantes.USER_NOT_FOUND));
    }
}
