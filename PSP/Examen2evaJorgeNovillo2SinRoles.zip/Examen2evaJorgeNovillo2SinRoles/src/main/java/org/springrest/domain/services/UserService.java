package org.springrest.domain.services;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springrest.common.Constantes;
import org.springrest.dao.UsersDatabase;
import org.springrest.domain.errors.NotFoundException;
import org.springrest.domain.model.User;

@Service
@RequiredArgsConstructor
public class UserService {

    private  final UsersDatabase usersDatabase;

    public boolean login(User user) {
        User foundUser = usersDatabase.getUsers().stream().filter(u -> u.getEmail().equals(user.getEmail()) && u.isActive()).findFirst().orElse(null);
        if (foundUser == null)
            throw new NotFoundException(Constantes.USER_NOT_FOUND);
        else
            return user.getPassword().equals(foundUser.getPassword());
    }


    public User findUserByEmail(String email) {
        return usersDatabase.findUserByEmail(email);
    }
}
