package org.springrest.domain.model;

import lombok.*;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class RolesEntity {
    private Integer id;
    private String rol;
}
